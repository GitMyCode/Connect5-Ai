package astar;

import java.util.PriorityQueue;

/**
 * Created by MB on 9/25/2014.
 */
public class Queue extends PriorityQueue{




}
